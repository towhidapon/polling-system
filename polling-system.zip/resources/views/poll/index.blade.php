@extends('layout.app')

@section('content')
    <section class="hero-section">
        <div class="container">
            <h1>@lang('Welcome to the Polling System')</h1>
            <p>@lang('voice matters! Participate in polls and make a difference.') </p>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#optionModal">@lang('Create Poll')</button>
        </div>
    </section>

    <div class="container my-5 ">
        <div class="row poll-parent">
            @foreach ($polls as $poll)
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="poll-card">
                            <div class="card-header">
                                <h4>{{ __($poll->question) }}</h4>
                            </div>
                            <div class="card-body fixed-card">
                                <div class="row poll-list">
                                    @foreach ($poll->options as $index => $option)
                                        <div class="col-6">
                                            <div class="form-check">
                                                <input class="form-check-input votes" type="radio" data-poll_id="{{ $poll->id }}" value="{{ $option->id }}" id="flexRadio{{ $option->id }}"
                                                    @if (in_array($option->id, $poll->checkOption())) checked @endif @if (!in_array($option->id, $poll->checkOption()) && in_array($poll->id, $poll->checkPoll())) disabled @endif>
                                                @error('expires_at')
                                                    <div class="alert alert-danger">{{ $message }}</div>
                                                @enderror
                                                <label class="form-check-label" for="flexRadio{{ $option->id }}">
                                                    {{ __($option->option) }} @lang('Votes') : {{ $option->votes }}
                                                </label>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    <div class="modal fade" id="optionModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="optionModalLabel">@lang('Create New Poll')</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="pollForm" method="post">
                        @csrf
                        <div class="mb-3 modal-body">
                            <label for="poll-question" class="col-form-label">@lang('Poll Question:')</label>
                            <input type="text" class="form-control" name="question" id="poll-question" value="{{ request()->question }}" placeholder="@lang('Enter your question here')" required>
                            @error('question')
                                <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group mt-3 text-end">
                            <button type="button" class="btn btn-primary btn-sm add-btn">@lang('Add')</button>
                        </div>
                        <div class="form-group mt-3">
                            <label for="expires_at">@lang('Expiry Date')</label>
                            <input type="datetime-local" id="expires_at" name="expires_at" class="form-control">
                            @error('expires_at')
                                <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="option-wrapper row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="">@lang('Option')</label>
                                    <div class="option-list">
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" name="options[]" value="{{ request()->question }}" required>
                                            @error('options')
                                                <div class="alert alert-danger">{{ $message }}</div>
                                            @enderror
                                            <span class="input-group-text bg-danger text-white close-btn cursor-default">X</span>
                                        </div>
                                    </div>
                                </div>

                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">@lang('Close')</button>
                            <button type="submit" class="btn btn-primary" id="save-poll">@lang('Save Poll')</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

    @push('script')
        <script>
            var index = 0
            $('.add-btn').on('click', function() {
                $('.option-wrapper').append(
                    `<div class="input-group mb-3">
                    <input type="text" class="form-control" name="options[]" required>
                    <span class="input-group-text bg-danger text-white close-btn cursor-default">X</span>
                </div>`
                );
            });

            $('.option-wrapper').on('click', '.close-btn', function() {
                $(this).closest('.input-group').remove();
            });

            $('.pollForm').on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData(this)
                $.ajax({
                    type: "post",
                    url: "{{ route('poll.store') }}",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        if (response.success) {
                            getPollList();
                            $('#optionModal').modal('hide');
                        }
                        alert(response.message);
                    }

                });
            });

            $(document).on('click', '.votes', function() {
                const pollId = $(this).data('poll_id');
                const optionId = $(this).val();

                $.ajax({
                    type: "POST",
                    url: "{{ route('poll.vote') }}",
                    data: {
                        'poll_id': pollId,
                        'option_id': optionId,
                    },
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    dataType: "json",
                    success: function(response) {
                        getPollList();
                        alert(response.message);


                    }

                });
            });

            function getPollList() {
                $.ajax({
                    url: "{{ route('poll.index') }}",
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log(response);

                        if (response.success) {
                            $('.poll-parent').html(response.html);
                        }
                    }
                });
            }
        </script>
    @endpush
@endsection
