@foreach ($polls as $poll)
    <div class="col-md-4 mb-3">
        <div class="card">
            <div class="poll-card">
                <div class="card-header">
                    <h4>{{ __($poll->question) }}</h4>
                </div>
                <div class="card-body fixed-card">
                    <div class="row poll-list">
                        @foreach ($poll->options as $index => $option)
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input votes" type="radio" data-poll_id="{{ $poll->id }}" value="{{ $option->id }}" id="flexRadio{{ $option->id }}"
                                        @if (in_array($option->id, $poll->checkOption())) checked @endif @if (!in_array($option->id, $poll->checkOption()) && in_array($poll->id, $poll->checkPoll())) disabled @endif>
                                    @error('expires_at')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                    <label class="form-check-label" for="flexRadio{{ $option->id }}">
                                        {{ __($option->option) }} @lang('Votes') : {{ $option->votes }}
                                    </label>
                                </div>
                            </div>
                        @endforeach

                    </div>
                </div>
            </div>
        </div>
    </div>
@endforeach
